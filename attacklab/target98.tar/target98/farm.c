/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_204(unsigned x)
{
    return x + 3347597535U;
}

unsigned getval_220()
{
    return 3267856712U;
}

unsigned getval_142()
{
    return 2425393752U;
}

void setval_459(unsigned *p)
{
    *p = 2428995912U;
}

void setval_323(unsigned *p)
{
    *p = 2428995912U;
}

unsigned getval_497()
{
    return 3277359578U;
}

unsigned getval_119()
{
    return 2425378853U;
}

void setval_296(unsigned *p)
{
    *p = 2425376769U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_365(unsigned *p)
{
    *p = 2425668233U;
}

unsigned getval_475()
{
    return 3375943305U;
}

void setval_378(unsigned *p)
{
    *p = 3767093764U;
}

unsigned getval_105()
{
    return 3467184999U;
}

void setval_233(unsigned *p)
{
    *p = 2425409165U;
}

unsigned getval_291()
{
    return 3677930153U;
}

unsigned getval_341()
{
    return 3375940233U;
}

unsigned addval_249(unsigned x)
{
    return x + 3529560457U;
}

unsigned getval_374()
{
    return 3281112713U;
}

void setval_180(unsigned *p)
{
    *p = 3221803405U;
}

void setval_227(unsigned *p)
{
    *p = 3674263177U;
}

unsigned addval_243(unsigned x)
{
    return x + 3525362315U;
}

void setval_193(unsigned *p)
{
    *p = 3268315603U;
}

unsigned getval_362()
{
    return 3674788249U;
}

unsigned getval_372()
{
    return 3286272328U;
}

unsigned addval_344(unsigned x)
{
    return x + 3286272328U;
}

void setval_104(unsigned *p)
{
    *p = 3674787465U;
}

unsigned getval_167()
{
    return 2429651384U;
}

void setval_216(unsigned *p)
{
    *p = 2447411528U;
}

unsigned getval_133()
{
    return 3682910729U;
}

unsigned getval_350()
{
    return 3375944073U;
}

unsigned addval_143(unsigned x)
{
    return x + 3269495112U;
}

unsigned addval_342(unsigned x)
{
    return x + 3224945289U;
}

unsigned getval_272()
{
    return 2429452681U;
}

unsigned getval_304()
{
    return 3269495112U;
}

void setval_211(unsigned *p)
{
    *p = 3281047944U;
}

void setval_300(unsigned *p)
{
    *p = 3767097372U;
}

unsigned addval_162(unsigned x)
{
    return x + 2430632264U;
}

unsigned getval_328()
{
    return 2429652269U;
}

unsigned getval_127()
{
    return 3375940237U;
}

unsigned getval_100()
{
    return 2495777241U;
}

void setval_184(unsigned *p)
{
    *p = 2425409993U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
